function R = get_rot(theta)

R = [cos(theta) -sin(theta) ;
    sin(theta) cos(theta)];